﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pharmacy_Management_System.Presentation_Layer.Data_Access_Layer
{
    class Category
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}